THEMIS RESILIENCE GROUP - WEBSITE
=================================
Files: index.html (the whole site, one file, no build step).

1) PUBLISH FREE (pick one)
 - Cloudflare Pages / Netlify: create an account, choose "Deploy manually" / "Drag and drop", drop this folder. You get a live address in a minute.
 - GitHub Pages: new repository, upload index.html, Settings > Pages > deploy from main branch.

2) CUSTOM DOMAIN
 Buy a domain (for example themisresilience.org or .africa / .ke from a registrar), then in your host's Domains section add it and follow the DNS instructions. HTTPS is automatic.

3) MAKE THE CONTACT FORM SEND EMAIL
 - Create a free form at formspree.io pointed at your email, copy its URL (looks like https://formspree.io/f/abcd1234).
 - Open index.html, find: var ENDPOINT='';  and paste the URL between the quotes.
 - Until you do this, the page shows "Copy enquiry" only and sends nothing.

4) BEFORE GOING LIVE
 - Check every service line is one you can deliver.
 - Decide which email address to show (search index.html for nicoleagnes361@gmail.com, two places). A domain email such as hello@yourdomain looks more credible.
 - Add a Publications section once your CCW / COP31 pieces and brief are public.
